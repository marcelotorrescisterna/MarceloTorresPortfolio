import sys
import pandas as pd
from sqlalchemy import create_engine
import nltk
nltk.download(['punkt', 'wordnet'])

# import statements
import re
import pandas as pd
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer

from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score , accuracy_score , recall_score
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import CountVectorizer , TfidfTransformer
import pickle

def load_data(database_filepath):
    """
    Loads the data from the sql database into a dataframe and outputs X (features) , Y (target) and category names (names of all the categories of messages)
    
    INPUT:
        database_filepath : path to the sql database
    
    OUTPUT:
        X : features
        Y : target values
        category_names : name of the categories
    """
    engine = create_engine(f'sqlite:///{database_filepath}')
    df = pd.read_sql("SELECT * FROM DisasterResponse", engine)
    X = df['message']
    Y = df[df.columns[4:]]
    category_names = Y.columns.values
    return X , Y , category_names


def tokenize(text):
    
    """
    Used to preprocess text and change it into a numerical format
    
    INPUT:
        text: any text
    OUTPUT:
        clean_tokes: Tokenized Text
    """
    tokens = word_tokenize(text)
    lemmatizer = WordNetLemmatizer()

    clean_tokens = []
    for tok in tokens:
        clean_tok = lemmatizer.lemmatize(tok).lower().strip()
        clean_tokens.append(clean_tok)
    return clean_tokens


def build_model():
    """
    Creates a Pipeline to build a classifier
    """
    pipeline = Pipeline([
        ('vect' , CountVectorizer(tokenizer=tokenize)),
        ('tfidf', TfidfTransformer()),
        ('clf' , RandomForestClassifier())
    ])
    parameters = {
            #'vect__ngram_range': ((1, 1), (1, 2)),
            #'vect__max_df': (0.5, 0.75, 1.0),
            #'vect__max_features': (None, 5000, 10000),
            #'tfidf__use_idf': (True, False),
            'clf__n_estimators': [50, 100, 200],
            #'clf__min_samples_split': [2, 3, 4]
        }


    cv = GridSearchCV(pipeline, param_grid=parameters , n_jobs=4 , verbose=2 , cv = 2 , scoring="accuracy")
    return cv


def evaluate_model(model, X_test, Y_test, category_names):
    """
    Evaluates de performance of the model on each category
    
    INPUTS:
        model: Trained model
        X_test : Testing Features
        Y_test : Ground Truth Testing Labels
        category_names : Category Names
    """
    y_pred = model.best_estimator_.predict(X_test)
    for c,i in enumerate(category_names):
        print(f"F1 Score for Category {i} : {f1_score(Y_test[i], y_pred[:,c], average='macro')}")
        
def save_model(model, model_filepath):
    """
    Saves the model into a pickle file
    
    INPUTS: 
        model: Trained model
    """
    with open(model_filepath,'wb') as f:
        pickle.dump(model.best_estimator_,f)


def main():
    if len(sys.argv) == 3:
        database_filepath, model_filepath = sys.argv[1:]
        print('Loading data...\n    DATABASE: {}'.format(database_filepath))
        X, Y, category_names = load_data(database_filepath)
        X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2)
        
        print('Building model...')
        model = build_model()
        
        print('Training model...')
        model.fit(X_train, Y_train)
        
        print('Evaluating model...')
        evaluate_model(model, X_test, Y_test, category_names)

        print('Saving model...\n    MODEL: {}'.format(model_filepath))
        save_model(model, model_filepath)

        print('Trained model saved!')

    else:
        print('Please provide the filepath of the disaster messages database '\
              'as the first argument and the filepath of the pickle file to '\
              'save the model to as the second argument. \n\nExample: python '\
              'train_classifier.py ../data/DisasterResponse.db classifier.pkl')


if __name__ == '__main__':
    main()